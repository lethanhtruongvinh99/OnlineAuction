# PTUDW_FinalProject_OnlineAuction

13:26 30/12/2019
    - Thêm dotenv, để lưu các biến môi trường.

13:41 29/12/2019
    - Thêm nodemon, start server bằng nodemon:
    "npm dev"
    "npm start": chạy server không dùng nodemon
    - Thêm nodemailer để gửi mail xác nhận.
    "onlineauction.mailcenter@gmail.com" "db_admin_pw"