var nodemailer = require("nodemailer");

var transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "onlineauctioncq2017@gmail.com",
    pass: "Onlineauction"
  }
});

var mailOptions = {
  from: "onlineauctioncq2017@gmail.com",
  to: "blkgn157@gmail.com",
  subject: "Sending Email using Node.js",
  text: "That was easy!"
};

module.export = {
  sendMail: transporter.sendMail(mailOptions, function(error, info) {
    if (error) {
      console.log(error);
    } else {
      console.log("Email sent: " + info.response);
    }
  })
};
